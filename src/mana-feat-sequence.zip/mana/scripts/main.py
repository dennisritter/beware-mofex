import numpy as np
from mana.models.sequence import Sequence
from mana.utils.data_operations.loaders.sequence_loader_mka import SequenceLoaderMKA
from mana.models.sequence_transforms import SequenceTransforms
from mana.utils.visualization.pose_visualization import vis_pose

root = './data/mka-beware-1.1/squat/'

st = SequenceTransforms(SequenceTransforms.mka_to_iisy())
slmka = SequenceLoaderMKA(st)
seq = slmka.load(f'{root}/squat_1.json')
seq.to_motionimg(show_img=True)